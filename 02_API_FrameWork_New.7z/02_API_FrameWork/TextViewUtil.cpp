#include "TextViewUtil.h"
#include "MouseUtil.h"
TextViewUtil::TextViewUtil() { }
TextViewUtil::~TextViewUtil() { }

void TextViewUtil::SetFont(LPCWSTR fontName) {
	_FontName = fontName;
}

void TextViewUtil::SetFontSize(INT size) {
	_FontSize = size;
}

void TextViewUtil::SetFontStyle(
	bool useBold, bool useItalic, 
	bool useUnderLine, bool useStrikeout) {
	_FontStyle =
		// ���� ���
		(FontStyleBold * useBold) |
		// ����̱�
		(FontStyleItalic * useItalic) |
		// �� ��
		(FontStyleUnderline * useUnderLine) |
		// ��� ��
		(FontStyleStrikeout * useStrikeout);
}

void TextViewUtil::SetFontColor(
	BYTE r, BYTE g, BYTE b, BYTE a = 255) {
	cR = r;
	cG = g;
	cB = b;
	cA = a;
}

Color TextViewUtil::GetFontColor() {
	return Color(cA, cR, cG, cB);
}

void TextViewUtil::SetPosition(INT x, INT y) {
	_Position.X = x;
	_Position.Y = y;
}

wstring TextViewUtil::GetText() {
	return _Text;
}

void TextViewUtil::SetText(wstring text) {
	_Text = text;
}

void TextViewUtil::AddText(wstring addText) {
	_Text.append(addText);
}

void TextViewUtil::DrawTextView(HDC hdc) {
	
	Graphics g(hdc);

	Font font(_FontName, _FontSize, _FontStyle, UnitPixel);

	SolidBrush myBrush(Color(cA, cR, cG, cB));

	g.DrawString(

		// ����� ���ڿ�
		_Text.c_str(),

		// ���ڿ� ����
		lstrlen(_Text.c_str()),

		// ��Ʈ ��ü
		&font,

		// ��ġ (left top)
		_Position,

		// �귯��
		&myBrush);
}
