#include "TextTest.h"



TextTest::TextTest()
{
	Init();
}


TextTest::~TextTest(){}

void TextTest::Init()
{
	Log("TextTest", "Success");

	LoadBMPImg(TEXT("Resource/TEXT1.bmp"));

	SetObjectWH(300, 50);

	m_PosX = 222;
	m_PosY = 200;

	m_UseTransparent = true;

	SetTransparentColor(RGB(255, 0, 255));
	
	//m_DebugMode = true;
	
	//m_DebugPosition = true;
	
	//m_DebugMoveMousePos = true;
}

void TextTest::Update()
{
	BaseUpdate();
}

void TextTest::Render(HDC hdc)
{
	BaseRender(hdc);
}
