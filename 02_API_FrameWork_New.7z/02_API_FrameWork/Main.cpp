#include "Main.h"
#include "TextTest.h"
#include "NewButton.h"

Main::Main()
{
	Init();
}


Main::~Main()
{
}

void Main::SafeRelease()
{
	if (_TT != null) {
		delete _TT;
		_TT = null;
	}
	if (_Btt != null) {
		delete _Btt;
		_Btt = null;
	}
}

void Main::OnEnable()
{
	if (_TT == null) _TT = new TextTest();
	if (_Btt == null) _Btt = new NewButton();
}

void Main::OnDisable()
{
}

void Main::Init()
{
}

void Main::Update()
{
	_TT->Update();
	_Btt->Update();
}

void Main::Render(HDC hdc)
{
	_TT->Render(hdc);
	_Btt->Render(hdc);
}
