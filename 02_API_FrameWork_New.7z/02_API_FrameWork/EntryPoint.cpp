
#include "Defines.h"
#include "GameManager.h"


bool g_WindowActive = true;
GameManager* g_GameManager;

INT WINAPI WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevIns,
	LPSTR lpCmdLine, INT nCmdShow) {

	g_GameManager = GameManager::GetGameManager();
	return g_GameManager->Loop(hInstance, nCmdShow);
}

