#pragma once
#include "Scene.h"
class PlayGroundMap :
	public Scene
{
public:
	PlayGroundMap();
	virtual ~PlayGroundMap();
	
private:
	class PlayGround* _Map = null;
	class Character * _char = null;
	class Skill * _skill = null;

public:
	virtual void SafeRelease() override;
	virtual void OnEnable() override;
	virtual void OnDisable() override;

	virtual void Init() override;
	virtual void Update() override;
	virtual void Render(HDC hdc) override;
};

