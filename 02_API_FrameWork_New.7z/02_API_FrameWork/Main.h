#pragma once
#include "Scene.h"
class Main :
	public Scene
{
private :
	class TextTest* _TT = null;
	class Button* _Btt = null;
public:
	Main();
	virtual ~Main();

	virtual void SafeRelease() override;
	virtual void OnEnable() override;
	virtual void OnDisable() override;
	virtual void Init() override;
	virtual void Update() override;
	virtual void Render(HDC hdc) override;
};

