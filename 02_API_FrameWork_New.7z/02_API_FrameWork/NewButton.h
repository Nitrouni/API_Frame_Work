#pragma once
#include "Button.h"
class NewButton :
	public Button
{
public:
	NewButton();
	virtual ~NewButton();

	virtual void Init() override;
	virtual void Update() override;
	virtual void Render(HDC hdc) override;

private:
	int rnlcksk = -2;
	int day = 65 * 60 * 60 * 24;
};

