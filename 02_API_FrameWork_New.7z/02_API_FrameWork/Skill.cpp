#include "Skill.h"
#include "Character.h"
#include "GameManager.h"
#include "SceneManager.h"

Skill::Skill()
{
	Init();
}


Skill::~Skill()
{
}

void Skill::OnEnable()
{
	area = {
		m_PosX - m_Width / 2,
		m_PosY - m_Height / 2,
		m_PosX + m_Width / 2,
		m_PosY + m_Height / 2
	};
}

void Skill::Init()
{
	Log("Skill", "Success");
	LoadBMPImg(TEXT("Resource/Moon.bmp"));
	SetObjectWH(16, 16);
	SetCropSize(20, 20);
	m_UseSprite = true;
	m_UseTransparent = true;
	//m_PosX = WND_WIDTH / 2;
	//m_PosY = WND_HEIGHT / 2;
	//SetSpriteDelay(100);
	SetTransparentColor(RGB(255, 0, 255));
}

void Skill::Update()
{
	BaseUpdate();


	// ��ų ������Ʈ �̵�
	if (_EnableSkil) SkillMove();
}

void Skill::Render(HDC hdc)
{
	BaseRender(hdc);
	//MovePosition();
}

void Skill::SkillMove()
{

	m_PosX += _MoveXSpeed;
	m_PosY += _MoveYSpeed;
}

void Skill::EnableSkill(POINT position, string dir)
{
	m_PosX = position.x;
	m_PosY = position.y;

	if (Equals(dir, "right")) _MoveXSpeed = 10;
	else if (Equals(dir, "left")) _MoveXSpeed = -10;
	else if (Equals(dir, "up")) _MoveYSpeed = -10;
	else if (Equals(dir, "down")) _MoveYSpeed = 10;
	else if (Equals(dir, "leftup")) { _MoveXSpeed = -10; _MoveYSpeed = -10; }
	else if (Equals(dir, "leftdown")) { _MoveXSpeed = -10; _MoveYSpeed = 10; }
	else if (Equals(dir, "rightup")) { _MoveXSpeed = 10; _MoveYSpeed = -10; }
	else if (Equals(dir, "rightdown")) { _MoveXSpeed = 10; _MoveYSpeed = 10; }

	_EnableSkil = true;
}

/*void Skill::MovePosition()
{
	Character * _char = new Character();
	if (GetTickCount() - _InputCheckTime > 50) {
		_InputCheckTime = GetTickCount();
		_MoveX = _char->_MoveX;
		_MoveY = _char->_MoveY;
	}
	m_PosX += _MoveX * _MoveSpeed;
	m_PosY += _MoveY * _MoveSpeed;
}*/

