#include "CharacterManager.h"
#include "Character.h"


CharacterManager::CharacterManager()
{
	Init();
}


CharacterManager::~CharacterManager()
{
	if (_Character != null) {
		delete _Character;
		_Character = null;
	}
}

void CharacterManager::Init()
{
	if (_Character == null) {
		_Character = new Character();
	}
}

Character * CharacterManager::GetCharacter()
{
	return _Character;
}
