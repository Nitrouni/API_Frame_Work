#include "InputManager.h"
InputManager::InputManager() { }
InputManager::~InputManager() { }

INT InputManager::GetHoriInputAxis() {
	int axis = 0;
	if (GetAsyncKeyState(RIGHT) && axis > -1) axis += 1;
	if (GetAsyncKeyState(LEFT) && axis < 1) axis -= 1;
	if (GetAsyncKeyState(RIGHT) && GetAsyncKeyState(LEFT))
		axis = 0;

	return axis;
}

INT InputManager::GetVerInputAxis() {
	int axis = 0;
	if (GetAsyncKeyState(UP) && axis < 1) axis -= 1;
	if (GetAsyncKeyState(DOWN) && axis > -1) axis += 1;
	if (GetAsyncKeyState(UP) && GetAsyncKeyState(DOWN))
		axis = 0;

	return axis;
}
