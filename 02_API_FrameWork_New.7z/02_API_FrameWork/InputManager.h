#pragma once
#include "Defines.h"

#define RIGHT	VK_RIGHT
#define LEFT	VK_LEFT
#define UP		VK_UP
#define DOWN	VK_DOWN

class InputManager final {
public:
	InputManager();
	~InputManager();


public :
	static INT GetHoriInputAxis();
	static INT GetVerInputAxis();
};

