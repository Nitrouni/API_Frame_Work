#include "PlayGroundMap.h"
#include "Character.h"
#include "PlayGround.h"
#include "GameManager.h"
#include "Skill.h"

PlayGroundMap::PlayGroundMap()
{
	Init();
}


PlayGroundMap::~PlayGroundMap()
{
}

void PlayGroundMap::SafeRelease()
{
	if (_Map != null) {
		delete _Map;
		_Map = null;
	}
	if (_char != null) {
		delete _char;
		_char = null;
	}
	if (_skill != null) {
		delete _skill;
		_skill = null;
	}
}

void PlayGroundMap::OnEnable()
{
	if (_Map == null) {
		_Map = new PlayGround();
	}
	if (_char == null) {
		_char = g_GameManager->GetCharacterManager()->GetCharacter();
	}
	if (_skill == null) {
		_skill = new Skill();
	}
	Log("PlayGround", "Success");
}

void PlayGroundMap::OnDisable()
{
	_char = null;
}

void PlayGroundMap::Init()
{
}

void PlayGroundMap::Update()
{
	_Map->Update();
	_char->Update();
	//_char->UseSkill(_skill);
	_skill->Update();
}

void PlayGroundMap::Render(HDC hdc)
{
	_Map->Render(hdc);
	_char->Render(hdc);
	_skill->Render(hdc);
}
