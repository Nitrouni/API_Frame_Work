#include "CameraUtil.h"



CameraUtil::CameraUtil() {
}


CameraUtil::~CameraUtil() {
}

CameraUtil * CameraUtil::GetCam() {
	static CameraUtil cam;
	return &cam;
}

int CameraUtil::GetPositionX() {
	return _PosX;
}

int CameraUtil::GetPositionY() {
	return _PosY;
}

void CameraUtil::SetPosition(POINT pos) {
	_PosX = pos.x;
	_PosY = pos.y;
}

void CameraUtil::SetPosition(POS positionType, int value) {
	switch (positionType) {
	case POS::X: _PosX += value; break;
	case POS::Y: _PosY += value; break;
	}
}

void CameraUtil::AddPositionX(int posX) {
	_PosX += posX;
}

void CameraUtil::AddPositionY(int posY) {
	_PosY += posY;
}
