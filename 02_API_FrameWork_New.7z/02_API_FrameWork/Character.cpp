#include "Character.h"
#include "InputManager.h"
#include "GameManager.h"
#include "SceneManager.h"
#include "Skill.h"
//#include "Portal.h"

#define HORI_INPUT Input->GetHoriInputAxis()
#define VER_INPUT Input->GetVerInputAxis()


Character::Character() {
	Init();
}

Character::~Character() {
	for (auto iter = _Skill.begin();
		iter != _Skill.end();
		iter++) {

		delete *iter;
		*iter = NULL;
	}

	_Skill.clear();
}

void Character::InputKey() {

	if (GetTickCount() - _InputCheckTime > 50) {
		_InputCheckTime = GetTickCount();
		_MoveX = HORI_INPUT;
		_MoveY = VER_INPUT;

		if (m_PosX <= (m_Width / 4) &&
			_MoveX == -1) {
			m_PosX = (m_Width / 4);
			_MoveX = 0;
		}
		else if (m_PosX >= WND_WIDTH - (m_Width / 2) &&
			_MoveX == 1) {
			m_PosX = WND_WIDTH - (m_Width / 2);
			_MoveX = 0;
		}

		if (m_PosY <= (m_Height / 2) &&
			_MoveY == -1) {
			m_PosY = (m_Height / 2);
			_MoveY = 0;
		}
		else if (m_PosY >= WND_HEIGHT - m_Height &&
			_MoveY == 1) {
			m_PosY = WND_HEIGHT - m_Height;
			_MoveY = 0;
		}
	}

	// �ִϸ��̼� ����� ���� �����Դϴ�.
	string animName = "";

	// (_MoveX == 0 && _MoveY == 0) ���� ����:
	// ���� ����, ���� �̵��� ���ٸ�
	animName.append((_MoveX == 0 && _MoveY == 0) ? "IDLE_" : "MOVE_");

	// ���� ������̶��
	if (Equals(animName, "IDLE_")) {
		switch (_Dir) {
		case Dir::DIR_LEFT:		animName.append("LEFT"); break;
		case Dir::DIR_RIGHT:		animName.append("RIGHT"); break;
		case Dir::DIR_UP:			animName.append("UP"); break;
		case Dir::DIR_DOWN:		animName.append("DOWN"); break;

		case Dir::DIR_LEFTUP:		animName.append("LEFTUP"); break;
		case Dir::DIR_LEFTDOWN:	animName.append("LEFTDOWN"); break;
		case Dir::DIR_RIGHTUP:	animName.append("RIGHTUP"); break;
		case Dir::DIR_RIGHTDOWN:	animName.append("RIGHTDOWN"); break;
		}
	}
	// �̵� ����̶��
	else if (Equals(animName, "MOVE_")) {
		if (_MoveX > 0) animName.append("RIGHT");
		else if (_MoveX < 0) animName.append("LEFT");

		if (_MoveY < 0) animName.append("UP");
		else if (_MoveY > 0) animName.append("DOWN");
	}

	PlayAnim(animName);
}

void Character::Ultra()
{
	if (GetAsyncKeyState(Key_Z)&&!ToggleU&&CoolT<=0) {
		CoolT = 4550;
		UTime = 135;
		ToggleU = true;
	}
	//else if (GetAsyncKeyState(Key_Z) && ToggleU) {
	//	ToggleU = false;
	//}
}

void Character::MovePosition() {
	if (GetAsyncKeyState(VK_SHIFT)) {
		m_PosX += _MoveX * (_MoveSpeed * 2);
		m_PosY += _MoveY * (_MoveSpeed * 2);
	}
	else {
		m_PosX += _MoveX * _MoveSpeed;
		m_PosY += _MoveY * _MoveSpeed;
	}
}

void Character::PlayAnim(string animName) {

	// �ִϸ��̼� �ߺ� ����� �������� ���ǹ�
	// _CurrentAnimName �� animName�� ���� ���� ���ٸ�
	if (Equals(_CurrentAnimName, animName)) return;

	// ���� ���� �ٸ��ٸ�(���� ������� �ִϸ��̼ǰ� �ٸ�
	// �ִϸ��̼��� ����Ϸ��� �Ѵٸ�)
	_CurrentAnimName = animName;

	CheckNamePlay(_CurrentAnimName);
}

void Character::CheckNamePlay(string playAnimName) {

	if (GetAsyncKeyState(VK_SHIFT)) {
		// IDLE
		if		(Equals(playAnimName, "IDLE_LEFT"))		SetAnimInfo(Dir::DIR_LEFT, 1000, 0, 0, 6);
		else if (Equals(playAnimName, "IDLE_RIGHT"))	SetAnimInfo(Dir::DIR_RIGHT, 1000, 0, 0, 2);
		else if (Equals(playAnimName, "IDLE_UP"))		SetAnimInfo(Dir::DIR_UP, 1000, 0, 0, 0);
		else if (Equals(playAnimName, "IDLE_DOWN"))		SetAnimInfo(Dir::DIR_DOWN, 1000, 0, 0, 4);

		else if (Equals(playAnimName, "IDLE_LEFTUP"))	SetAnimInfo(Dir::DIR_LEFTUP, 1000, 0, 0, 5);
		else if (Equals(playAnimName, "IDLE_LEFTDOWN"))	SetAnimInfo(Dir::DIR_LEFTDOWN, 1000, 0, 0, 7);
		else if (Equals(playAnimName, "IDLE_RIGHTUP"))	SetAnimInfo(Dir::DIR_RIGHTUP, 1000, 0, 0, 1);
		else if (Equals(playAnimName, "IDLE_RIGHTDOWN"))SetAnimInfo(Dir::DIR_RIGHTDOWN, 1000, 0, 0, 3);

		// MOVE

		else if (Equals(playAnimName, "MOVE_LEFT"))		SetAnimInfo(Dir::DIR_LEFT, 50, 1, 8, 6);
		else if (Equals(playAnimName, "MOVE_RIGHT"))	SetAnimInfo(Dir::DIR_RIGHT, 50, 1, 8, 2);
		else if (Equals(playAnimName, "MOVE_UP"))		SetAnimInfo(Dir::DIR_UP, 50, 1, 8, 0);
		else if (Equals(playAnimName, "MOVE_DOWN"))		SetAnimInfo(Dir::DIR_DOWN, 50, 1, 8, 4);

		else if (Equals(playAnimName, "MOVE_LEFTUP"))	SetAnimInfo(Dir::DIR_LEFTUP, 50, 1, 8, 5);
		else if (Equals(playAnimName, "MOVE_LEFTDOWN"))	SetAnimInfo(Dir::DIR_LEFTDOWN, 50, 1, 8, 7);
		else if (Equals(playAnimName, "MOVE_RIGHTUP"))	SetAnimInfo(Dir::DIR_RIGHTUP, 50, 1, 8, 1);
		else if (Equals(playAnimName, "MOVE_RIGHTDOWN"))SetAnimInfo(Dir::DIR_RIGHTDOWN, 50, 1, 8, 3);
	}
	else {
		// IDLE
		if (Equals(playAnimName, "IDLE_LEFT"))			SetAnimInfo(Dir::DIR_LEFT, 1000, 0, 0, 6);
		else if (Equals(playAnimName, "IDLE_RIGHT"))	SetAnimInfo(Dir::DIR_RIGHT, 1000, 0, 0, 2);
		else if (Equals(playAnimName, "IDLE_UP"))		SetAnimInfo(Dir::DIR_UP, 1000, 0, 0, 0);
		else if (Equals(playAnimName, "IDLE_DOWN"))		SetAnimInfo(Dir::DIR_DOWN, 1000, 0, 0, 4);

		else if (Equals(playAnimName, "IDLE_LEFTUP"))	SetAnimInfo(Dir::DIR_LEFTUP, 1000, 0, 0, 5);
		else if (Equals(playAnimName, "IDLE_LEFTDOWN"))	SetAnimInfo(Dir::DIR_LEFTDOWN, 1000, 0, 0, 7);
		else if (Equals(playAnimName, "IDLE_RIGHTUP"))	SetAnimInfo(Dir::DIR_RIGHTUP, 1000, 0, 0, 1);
		else if (Equals(playAnimName, "IDLE_RIGHTDOWN"))SetAnimInfo(Dir::DIR_RIGHTDOWN, 1000, 0, 0, 3);

		// MOVE

		else if (Equals(playAnimName, "MOVE_LEFT"))		SetAnimInfo(Dir::DIR_LEFT, 100, 1, 8, 6);
		else if (Equals(playAnimName, "MOVE_RIGHT"))	SetAnimInfo(Dir::DIR_RIGHT, 100, 1, 8, 2);
		else if (Equals(playAnimName, "MOVE_UP"))		SetAnimInfo(Dir::DIR_UP, 100, 1, 8, 0);
		else if (Equals(playAnimName, "MOVE_DOWN"))		SetAnimInfo(Dir::DIR_DOWN, 100, 1, 8, 4);

		else if (Equals(playAnimName, "MOVE_LEFTUP"))	SetAnimInfo(Dir::DIR_LEFTUP, 100, 1, 8, 5);
		else if (Equals(playAnimName, "MOVE_LEFTDOWN"))	SetAnimInfo(Dir::DIR_LEFTDOWN, 100, 1, 8, 7);
		else if (Equals(playAnimName, "MOVE_RIGHTUP"))	SetAnimInfo(Dir::DIR_RIGHTUP, 100, 1, 8, 1);
		else if (Equals(playAnimName, "MOVE_RIGHTDOWN"))SetAnimInfo(Dir::DIR_RIGHTDOWN, 100, 1, 8, 3);
	}
}

void Character::SetAnimInfo(Dir dir, int delay, int startIndex, int endIndex, int yIndex) {

	// ���� ����
	_Dir = dir;

	// ��������Ʈ ù ��° �ε����� �ʱ�ȭ�մϴ�.
	m_SpriteIndex = startIndex;

	// ��������Ʈ ������ ����
	SetSpriteDelay(delay);

	// ù ��°, �� ��° �ΰԽ� ����
	SetSpriteIndex(startIndex, endIndex);

	// Y �ε��� ����
	SetSpriteIndex(yIndex);

}

void Character::UpdateArea()
{
	area = {
		m_PosX - 10,
		m_PosY - 20,
		m_PosX + 10,
		m_PosY + 20,
	};
}

/*void Character::UsePortal(Portal * portal, string loadMap) {

	if (Equals(loadMap, "")) return;

	RECT dest;
	if (IntersectRect(&dest, &area, &portal->area))
		if (!_IsInPortal) _IsInPortal = true;

		else {
			if (_IsInPortal) _IsInPortal = false;
		}

	// �� ��ȯ
	if (GetAsyncKeyState(VK_SPACE) && _IsInPortal) {
		g_GameManager->GetSceneManager()->ChangeScene(loadMap);
		_IsInPortal = false;

	}
}*/

void Character::UseSkill()
{

	if (GetAsyncKeyState(Key_X)&0x0001) {


		Skill * skill = new Skill();
		POINT location = { m_PosX, m_PosY };

		if (_Dir == Dir::DIR_LEFT) { skill->SetSpriteIndex(4);		skill->EnableSkill(location, "left");		}
		if (_Dir == Dir::DIR_RIGHT) { skill->SetSpriteIndex(4);		skill->EnableSkill(location, "right");		}
		if (_Dir == Dir::DIR_UP) { skill->SetSpriteIndex(4);		skill->EnableSkill(location, "up");			}
		if (_Dir == Dir::DIR_DOWN) { skill->SetSpriteIndex(4);		skill->EnableSkill(location, "down");		}
		if (_Dir == Dir::DIR_LEFTUP) { skill->SetSpriteIndex(2);	skill->EnableSkill(location, "leftup");		}
		if (_Dir == Dir::DIR_LEFTDOWN) { skill->SetSpriteIndex(3);	skill->EnableSkill(location, "leftdown");	}
		if (_Dir == Dir::DIR_RIGHTUP) { skill->SetSpriteIndex(0);	skill->EnableSkill(location, "rightup");	}
		if (_Dir == Dir::DIR_RIGHTDOWN) { skill->SetSpriteIndex(1);	skill->EnableSkill(location, "rightdown");	}

		_Skill.push_back(skill);
		//skill->EnableSkill(location, "left");

	}
	else if (ToggleU) {


		Skill * skill = new Skill();
		Skill * skill1 = new Skill();
		Skill * skill2 = new Skill();
		Skill * skill3 = new Skill();
		Skill * skill4 = new Skill();
		Skill * skill5 = new Skill();
		Skill * skill6 = new Skill();
		Skill * skill7 = new Skill();
		POINT location = { m_PosX, m_PosY };

		skill->SetSpriteIndex(4);
		skill->EnableSkill(location, "left");
		skill1->SetSpriteIndex(4);
		skill1->EnableSkill(location, "right");
		skill2->SetSpriteIndex(4);
		skill2->EnableSkill(location, "up");
		skill3->SetSpriteIndex(4);
		skill3->EnableSkill(location, "down");
		skill4->SetSpriteIndex(2);
		skill4->EnableSkill(location, "leftup");
		skill5->SetSpriteIndex(3);
		skill5->EnableSkill(location, "leftdown");
		skill6->SetSpriteIndex(0);
		skill6->EnableSkill(location, "rightup");
		skill7->SetSpriteIndex(1);
		skill7->EnableSkill(location, "rightdown");

		_Skill.push_back(skill);
		_Skill.push_back(skill1);
		_Skill.push_back(skill2);
		_Skill.push_back(skill3);
		_Skill.push_back(skill4);
		_Skill.push_back(skill5);
		_Skill.push_back(skill6);
		_Skill.push_back(skill7);
		//skill->EnableSkill(location, "left");

	}
}

void Character::Init() {

	// �̹��� �ҷ�����
	LoadBMPImg(TEXT("Resource/Character.bmp"));

	// ������Ʈ ũ�� ����
	SetObjectWH(64, 64);

	// �̹��� ��������Ʈ �� ĭ ũ��
	// (�߶�� ũ��)
	SetCropSize(64, 64);

	// ��������Ʈ �̹����� ����մϴ�.
	m_UseSprite = true;

	// ������ ���
	m_UseTransparent = true;

	// ��������Ʈ ������ ����(0.1��)
	SetSpriteDelay(100);

	// ������ ���
	SetTransparentColor(RGB(255, 0, 255));

	m_PosX = WND_WIDTH / 2;
	m_PosY = WND_HEIGHT / 2;
}

void Character::Update() {
	// Ű �Է��� �޽��ϴ�.
	InputKey();
	if (GetTickCount() - _CheckTime > 100) {
		_CheckTime = GetTickCount();
		Ultra();
	}
	// �̵��� �����մϴ�.
	MovePosition();
	UpdateArea();
	BaseUpdate();
	if (CoolT > 0) {
		Log("Ultra / ��Ÿ�� üũ! : ", CoolT / 65);
	}
	if (UTime > 0) {
		Log("Ultra / ���ӽð� üũ! : ", UTime);
	}
	UseSkill();

	if (CoolT > 0) {
		CoolT--;
	}

	if (UTime > 0) {
		UTime--;
	}

	if (UTime <= 0) {
		ToggleU = false;
	}

	for (auto iter = _Skill.begin();
		iter != _Skill.end();
		iter++) {

		(*iter)->Update();
	}

}

void Character::Render(HDC hdc) {
	
	for (auto iter = _Skill.begin();
		iter != _Skill.end();
		iter++) {

		(*iter)->Render(hdc);
	}
	BaseRender(hdc);
}
