#include "NewButton.h"
#include "GameManager.h"
#include "SceneManager.h"


NewButton::NewButton()
{
	Init();
}


NewButton::~NewButton()
{
}

void NewButton::Init()
{
	Log("NewButton", "Success");
	LoadBMPImg(TEXT("Resource/ShiningKim.bmp"));

	SetObjectWH(50, 50);
	SetCropSize(100, 100);


	m_UseHover = true;

	m_UseTransparent = true;
	SetTransparentColor(RGB(255, 0, 255));

	m_PosX = 400;
	m_PosY = 74;
}

void NewButton::Update()
{
	if (CheckClick()&& rnlcksk==-2) {
	
		// �� ��ȯ!
		Log("ButtonTest_", "Click!");
		rnlcksk = 20000000;
		// SecondScene ���� ���� ��ȯ�մϴ�.
		//g_GameManager->GetSceneManager()->ChangeScene("PlayGround");
	}
	
	if (rnlcksk >= 0) {
		REMAINTIME(((((rnlcksk / 65)/60)/60)/24));
		rnlcksk--;
	}

	if (rnlcksk <= -1 && rnlcksk != -2) {
		g_GameManager->GetSceneManager()->ChangeScene("PlayGround");
	}
	BaseUpdate();
}

void NewButton::Render(HDC hdc)
{
	BaseRender(hdc);
}
