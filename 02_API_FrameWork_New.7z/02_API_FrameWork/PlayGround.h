#pragma once
#include "GameObject.h"
class PlayGround :
	public GameObject
{
public:
	PlayGround();
	virtual ~PlayGround();

	virtual void Init() override;
	virtual void Update() override;
	virtual void Render(HDC hdc) override;
};

